/**
 * BACKFILL SCRIPT — run once after deploying the fix
 *
 * Also drops the stale iscanAddress index that was crashing inserts.
 * Safe to run multiple times.
 *
 * Usage:
 *   node scripts/backfill-wallets.js
 */

import dotenv from 'dotenv';
dotenv.config();

import connectDB from '../config/db.js';
import User from '../src/models/userModel.js';
import Wallet from '../src/models/walletModel.js';

async function backfill() {
  const conn = await connectDB();

  // ── DROP STALE INDEX ──────────────────────────────────────────────────────
  // The wallets collection has an old unique index on iscanAddress from a
  // previous schema version. walletModel.js no longer defines this field,
  // but the index is still in MongoDB and blocks every insert with null.
  try {
    await Wallet.collection.dropIndex('iscanAddress_1');
    console.log('Dropped stale index: iscanAddress_1');
  } catch (e) {
    // Index didn't exist — that's fine
    console.log('No stale index to drop (already clean).');
  }
  // ─────────────────────────────────────────────────────────────────────────

  const users = await User.find({}, '_id email');
  console.log(`Found ${users.length} users to check.\n`);

  let created = 0;
  let skipped = 0;
  let failed  = 0;

  for (const user of users) {
    try {
      const existing = await Wallet.findOne({ userId: user._id });
      if (existing) {
        console.log(`  — Already has wallet: ${user.email}`);
        skipped++;
        continue;
      }

      await Wallet.create({ userId: user._id, balance: 0 });
      console.log(`  ✓ Created wallet for ${user.email}`);
      created++;
    } catch (err) {
      console.error(`  ✗ Failed for ${user.email}:`, err.message);
      failed++;
    }
  }

  console.log(`\nDone. Created: ${created}  |  Already existed: ${skipped}  |  Failed: ${failed}`);
  process.exit(0);
}

backfill().catch(err => {
  console.error('Backfill failed:', err);
  process.exit(1);
});
