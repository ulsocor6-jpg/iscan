import User from "../models/userModel.js";
import Wallet from "../models/walletModel.js";

/**
 * Create Wallet
 */
export const createWallet = async (req, res) => {
  try {
    const wallet = await Wallet.create({ userId: req.body.userId });
    res.json({ success: true, wallet });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

/**
 * Link Wallet
 */
export const linkWallet = async (req, res) => {
  try {
    const { address, provider, chainId, nativeBalance, nativeToken, usdcBalance } = req.body;

    const user = await User.findByIdAndUpdate(
      req.user.id,
      {
        $addToSet: {
          linkedWallets: {
            walletId: address,   // store address as the walletId key
            address,
            provider,
            chainId,
            nativeBalance,
            nativeToken,
            usdcBalance,
            addedAt: new Date()
          }
        }
      },
      { returnDocument: "after" }
    );

    // Return the internal wallet so the frontend can display the ISCAN address
    const internalWallet = await Wallet.findOne({ userId: req.user.id });

    res.json({
      success: true,
      user,
      // dashboard.js reads r.data.iscanAddress — return it here
      iscanAddress: internalWallet ? `ISCAN-${internalWallet._id.toString().slice(-10).toUpperCase()}` : null
    });

  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

/**
 * Unlink Wallet
 */
export const unlinkWallet = async (req, res) => {
  try {
    const { walletId } = req.body;

    const user = await User.findByIdAndUpdate(
      req.user.id,
      { $pull: { linkedWallets: { walletId } } },
      { returnDocument: "after" }
    );

    res.json({ success: true, user });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

/**
 * Get Wallets
 * dashboard.js calls /api/v1/wallet/list and reads:
 *   r.data.wallets        — array of linked web3 wallets
 *   r.data.iscanAddress   — the user's internal ISCAN identifier
 */
export const getWallets = async (req, res) => {
  try {
    // Linked web3 wallets stored on the user document
    const user = await User.findById(req.user.id).select('linkedWallets');
    const wallets = user?.linkedWallets || [];

    // Internal ISCAN wallet — used to derive the ISCAN address shown in the UI
    const internalWallet = await Wallet.findOne({ userId: req.user.id });

    // Derive a stable human-readable ISCAN address from the wallet _id.
    // Format: ISCAN-XXXXXXXXXX (last 10 chars of ObjectId, uppercased)
    const iscanAddress = internalWallet
      ? `ISCAN-${internalWallet._id.toString().slice(-10).toUpperCase()}`
      : null;

    res.json({ success: true, wallets, iscanAddress });

  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
