import mongoose from 'mongoose';

const transactionSchema = new mongoose.Schema(
  {
    senderId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true
    },

    receiverId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      required: true,
      index: true
    },

    senderAddress: {
      type: String,
      required: true,
      index: true
    },

    receiverAddress: {
      type: String,
      required: true,
      index: true
    },

    receiverEmail: {
      type: String,
      default: null
    },

    amount: {
      type: Number,
      required: true,
      min: 0
    },

    currency: {
      type: String,
      enum: ['PHP', 'USDC', 'USDT', 'FLOWER', 'ETH', 'MATIC', 'RON'],
      default: 'PHP',
      required: true,
      index: true
    },

    fee: {
      type: Number,
      default: 0
    },

    type: {
      type: String,
      enum: [
        'transfer',
        'remittance',
        'p2p',
        'cashin',
        'cashout',
        'swap'
      ],
      default: 'transfer'
    },

    status: {
      type: String,
      enum: [
        'created',
        'validating',
        'fraud_check',
        'reserved',
        'processing',
        'settled',
        'failed',
        'reversed',
        'pending',
        'completed'
      ],
      default: 'created',
      index: true
    },

    fraudScore: {
      type: Number,
      default: 0
    },

    fraudRisk: {
      type: String,
      default: 'LOW'
    },

    processAt: { type: Date, default: null },
    completedAt: { type: Date, default: null },
    ledgerGroupId: {
      type: String,
      required: true,
      default: 'ISCAN_MAIN_LEDGER',
      index: true
    },

    reservationId: {
      type: String,
      default: null
    },

    settlementMethod: {
      type: String,
      enum: [
        'coinsph',
        'maya',
        'paymongo',
        'bank',
        'manual'
      ],
      default: 'manual'
    },

    settlementRef: {
      type: String,
      default: null
    },

    referenceId: {
      type: String,
      required: true,
      unique: true,
      index: true
    },

    idempotencyKey: {
      type: String,
      unique: true,
      sparse: true
    },

    notes: {
      type: String,
      default: ''
    },

    metadata: {
      type: Object,
      default: {}
    }
  },
  {
    timestamps: true
  }
);

// Indexes
transactionSchema.index({ senderId: 1, createdAt: -1 });
transactionSchema.index({ receiverId: 1, createdAt: -1 });

// ✅ IMPORTANT FIX: proper default export
const Transaction = mongoose.model('Transaction', transactionSchema);
export default Transaction;
