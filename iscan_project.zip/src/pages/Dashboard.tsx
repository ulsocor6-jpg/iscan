import DashboardLayout from "../components/DashboardLayout";

import HeroBalance from "../components/HeroBalance";
import KPIRow from "../components/KPIRow";
import { useSession } from "../hooks/useSession";

import MarketsPanel from "../components/dashboard/MarketsPanel";
import ActivityFeed from "../components/dashboard/ActivityFeed";
import WalletPortfolio from "../components/dashboard/WalletPortfolio";
import TreasuryHealth from "../components/dashboard/TreasuryHealth";
import ComplianceSnapshot from "../components/dashboard/ComplianceSnapshot";

import { useDashboard } from "../hooks/useDashboard";
import { useAuth } from "../hooks/useAuth";

export default function Dashboard() {
  const { dashboard, loading } = useDashboard();
    const { user, loading: authLoading } = useAuth();
        const { user, loading } = useSession();

  if (loading) {
  return <div>Loading session...</div>;
}

if (!user) {
  return (
    <DashboardLayout>
      <div style={{ padding: 40 }}>
        Not authenticated — please login
      </div>
    </DashboardLayout>
  );
}

  if (!dashboard) {
    return (
      <DashboardLayout>
        <div style={{ padding: 40 }}>Dashboard unavailable</div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="dashboard">

        <HeroBalance data={dashboard.hero} />

        <KPIRow data={dashboard.kpi} />

        <div className="dashboard-grid">

          <MarketsPanel />

          <ActivityFeed data={dashboard.activity || []} />

          <WalletPortfolio data={dashboard.portfolio || []} />

          <TreasuryHealth data={dashboard.treasury} />

          <ComplianceSnapshot data={dashboard.compliance} />

        </div>

      </div>
    </DashboardLayout>
  );
}

if (authLoading) {
  return (
    <DashboardLayout>
      <div style={{ padding: 40 }}>Checking authentication...</div>
    </DashboardLayout>
  );
}

if (!user) {
  return (
    <DashboardLayout>
      <div style={{ padding: 40 }}>
        Not logged in. Please login.
      </div>
    </DashboardLayout>
  );
}
