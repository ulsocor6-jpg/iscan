import { useState } from "react";
import { register } from "../services/authService";

export default function Register() {
  const [firstName, setFirstName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function handleRegister() {
    try {
      await register({ firstName, email, password });
      alert("Registered. You can now login.");
      window.location.href = "/login";
    } catch (err: any) {
      alert(err.message);
    }
  }

  return (
    <div style={{ padding: 40 }}>
      <h2>Register</h2>

      <input placeholder="name" onChange={(e) => setFirstName(e.target.value)} />
      <input placeholder="email" onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="password" onChange={(e) => setPassword(e.target.value)} />

      <button onClick={handleRegister}>Create Account</button>
    </div>
  );
}
