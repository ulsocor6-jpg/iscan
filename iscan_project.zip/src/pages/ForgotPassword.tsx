import { useState } from "react";
import { forgotPassword } from "../services/authService";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");

  async function handleReset() {
    try {
      await forgotPassword(email);
      alert("Reset link sent (check email)");
    } catch (err: any) {
      alert(err.message);
    }
  }

  return (
    <div style={{ padding: 40 }}>
      <h2>Forgot Password</h2>

      <input
        placeholder="email"
        onChange={(e) => setEmail(e.target.value)}
      />

      <button onClick={handleReset}>
        Send Reset Link
      </button>
    </div>
  );
}
