const API_BASE = "/api/v1";

async function api(path: string, options: RequestInit = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.message || "Request failed");
  }

  return data;
}

/**
 * LOGIN
 */
export function login(email: string, password: string) {
  return api("/auth/login", {
    method: "POST",
    body: JSON.stringify({ email, password })
  });
}

/**
 * REGISTER
 */
export function register(payload: {
  email: string;
  password: string;
  firstName: string;
}) {
  return api("/auth/register", {
    method: "POST",
    body: JSON.stringify(payload)
  });
}

/**
 * LOGOUT
 */
export function logout() {
  return api("/auth/logout", {
    method: "POST"
  });
}

/**
 * GET CURRENT USER
 */
export function getMe() {
  return api("/auth/me");
}

/**
 * FORGOT PASSWORD
 */
export function forgotPassword(email: string) {
  return api("/auth/forgot-password", {
    method: "POST",
    body: JSON.stringify({ email })
  });
}

/**
 * RESET PASSWORD
 */
export function resetPassword(token: string, password: string) {
  return api("/auth/reset-password", {
    method: "POST",
    body: JSON.stringify({ token, password })
  });
}
