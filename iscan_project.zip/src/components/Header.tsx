export default function Header() {
  return (
    <header className="header">

      <div className="search">

        <input
          type="text"
          placeholder="Search users, wallets, tx hash..."
        />

      </div>

      <div className="header-actions">

        <button>🔔</button>

        <button>⚙️</button>

        <button>👤 Admin</button>

      </div>

    </header>
  );
}
