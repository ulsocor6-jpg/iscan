export default function Sidebar() {
  return (
    <aside className="sidebar">

      <div className="logo">
        ISCAN
      </div>

      <nav>

        <button className="active">
          Dashboard
        </button>

        <button>
          Deposits
        </button>

        <button>
          Transfers
        </button>

        <button>
          Swaps
        </button>

        <button>
          Remittance
        </button>

        <button>
          Treasury
        </button>

        <button>
          Compliance
        </button>

        <button>
          Activity
        </button>

        <button>
          Settings
        </button>

      </nav>

    </aside>
  );
}
