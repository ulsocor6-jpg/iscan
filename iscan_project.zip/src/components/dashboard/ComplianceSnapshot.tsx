type Props = {
  data: {
    approved: number;
    pending: number;
    rejected: number;
    amlAlerts: number;
  };
};

export default function ComplianceSnapshot({
  data
}: Props) {

  return (
    <div className="card">

      <h2>Compliance</h2>

      <div className="metric">
        <span>Approved</span>
        <strong>{data.approved}</strong>
      </div>

      <div className="metric">
        <span>Pending</span>
        <strong>{data.pending}</strong>
      </div>

      <div className="metric">
        <span>Rejected</span>
        <strong>{data.rejected}</strong>
      </div>

      <div className="metric">
        <span>AML Alerts</span>
        <strong>{data.amlAlerts}</strong>
      </div>

    </div>
  );
}
