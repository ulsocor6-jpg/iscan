import { createDepositAddress } from "../hooks/useDashboardActions";

type Props = {
  data?: {
    totalVolume?: number;
    totalTransactions?: number;
  };
};

export default function HeroBalance({ data }: Props) {

  async function handleDeposit() {
    try {
      const res = await createDepositAddress("tron", "USDT");
      console.log("DEPOSIT ADDRESS:", res);
      alert("Deposit address created: " + res.data.address);
    } catch (err: any) {
      console.error(err);
      alert("Deposit failed: " + err.message);
    }
  }

  return (
    <div className="hero-card">

      <div>ISCAN Operations Dashboard</div>

      <h1>
        ₱{(data?.totalVolume ?? 0).toLocaleString()}
      </h1>

      <div>
        {data?.totalTransactions ?? 0} Transactions Processed
      </div>

      <div style={{ marginTop: 20, display: "flex", gap: 10, flexWrap: "wrap" }}>

        <button onClick={handleDeposit}>
          Deposit
        </button>

        <button>
          Transfer
        </button>

        <button>
          Swap
        </button>

        <button>
          Remit
        </button>

      </div>

    </div>
  );
}
