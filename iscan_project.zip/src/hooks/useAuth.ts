import { useEffect, useState } from "react";
import { getMe } from "../services/authService";

export function useAuth() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    init();
  }, []);

  async function init() {
    try {
      const res = await getMe();
      setUser(res.data);
    } catch (err) {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }

  return {
    user,
    loading,
    isAuthenticated: !!user,
    refresh: init
  };
}
