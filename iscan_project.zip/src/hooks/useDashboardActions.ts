const API_BASE = "/api/v1";

/**
 * Generic helper for authenticated requests
 */
async function apiFetch(url: string, options: RequestInit = {}) {
  const res = await fetch(`${API_BASE}${url}`, {
    ...options,
    credentials: "include", // IMPORTANT: sends JWT cookie
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    }
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data?.message || "Request failed");
  }

  return data;
}

/**
 * Deposit address (TRC20 / ETH)
 */
export async function createDepositAddress(chain = "tron", token = "USDT") {
  return apiFetch("/onramp/deposit-address", {
    method: "POST",
    body: JSON.stringify({ chain, token })
  });
}

/**
 * Convert USDT → PHP
 */
export async function convertUSDT(payload: {
  token: string;
  usdAmount: number;
  channel: string;
  mobileNumber: string;
  depositId: string;
}) {
  return apiFetch("/onramp/convert", {
    method: "POST",
    body: JSON.stringify(payload)
  });
}

/**
 * Get quote
 */
export async function getQuote() {
  return apiFetch("/onramp/rate");
}

    setInterval(() => {
  loadDashboard();
}, 15000);
