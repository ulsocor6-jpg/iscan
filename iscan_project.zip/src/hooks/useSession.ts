import { useEffect, useState } from "react";

const API = "/api/v1/auth";

export function useSession() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const res = await fetch(`${API}/me`, {
        credentials: "include"
      });

      const json = await res.json();

      if (!json.success) {
        setUser(null);
      } else {
        setUser(json.data);
      }
    } catch (err) {
      setUser(null);
    } finally {
      setLoading(false);
    }
  }

  return { user, loading };
}
